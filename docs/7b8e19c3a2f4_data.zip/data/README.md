# SG4D Dataset & Directory Guide

This directory manages the trajectory, metadata, and cleaning states for the **Southbay Gull Foraging Dynamics (SG4D)** study.

> 📦 **DATA PACKAGE & COLLABORATION GUIDE**
>
> All tracking datasets and metadata are ignored in git tracking to prevent large files in version control. 
> To share this data package with collaborators:
> 
> **How to Package/Zip (For Senders):**
> Zip the contents of this `data/` folder (including `TRACKS 2026/`, `GFD Gull Foraging Dynamics Metadata.xlsx`, `gt_clean.csv`, etc.) or zip the `data/` folder itself.
>
> **How to Install (For Collaborators):**
> 1. Clone the repository.
> 2. Locate or create a `data/` folder in the root directory of the project.
> 3. Unzip the shared data package directly into this `data/` folder.
> 4. Ensure the files land exactly inside `data/` (e.g., `data/TRACKS 2026/...`, `data/gt_clean.csv`, etc.).
> 5. Run the pipeline or launch the dashboard:
>    ```bash
>    # Run the processing pipeline
>    uv run python3 src/main.py data process
>
>    # Run the tests to verify setup
>    uv run pytest
>    ```

The primary goals of this directory structure are:
1. Maintain clear, descriptive, and consistent file naming.
2. Provide a single clean dataset serving as the absolute source of truth.
3. Keep track of all raw, processed, and manually curated removal states.

---

## 1. Directory Layout & Description

All tracking datasets and outputs are organized by study year (**2019**, **2025**, and **2026**) inside their respective directories:

| Path | Type | Tracked in Git? | Description |
|---|---|---|---|
| `GFD Gull Foraging Dynamics Metadata.xlsx` | File | No (Ignored) | Master Excel sheet detailing bird IDs, colony groupings, and deployment/recovery times for all years. |
| `[year]/TRACKS/` | Folder | No (Ignored) | Contains raw `.gpx` and `.csv` files for that year, downloaded from GPS loggers. |
| `[year]/gt_raw.csv` | File | No (Ignored) | Consolidated raw trajectories of all birds for that year, combined by `sg4d data process`. |
| `[year]/gt_clean.csv` | File | No (Ignored) | **Single Clean Source of Truth** for that year. Fully processed, trimmed to deployment metadata, and noise-excised tracks. |
| `[year]/gt_removed.csv` | File | No (Ignored) | Contains all flagged noise points for that year (pre-deploy, post-recover, Santa Cruz corridor, speed-splits). |
| `[year]/known_removals.csv` | File | No (Ignored) | Persistent CSV ledger of points manually flagged for removal via the interactive cleaner. |
| `[year]/cleaning_status.csv` | File | No (Ignored) | Progress tracking log for which birds have been manually reviewed. |
| `[year]/gt_metadata_clean.csv` | File | No (Ignored) | Backward-compatible duplicate of `gt_clean.csv` to support legacy code references. |

---

## 2. Naming Conventions

*   **`gt_` Prefix:** Stands for **Gull Tracks**. All intermediate and final consolidated tracking datasets use this prefix for clean namespace partitioning.
*   **`_raw` suffix:** Indicates combined but completely unfiltered and uncropped GPS points.
*   **`_clean` suffix:** Represents the final, curated, publication-ready dataset containing biological foraging trajectories.
*   **`_removed` suffix:** Indicates the companion noise log containing all non-biological and out-of-bounds transport points (replacing the legacy `gt_car_only.csv`).

---

## 3. Data Processing & Cleaning Pipeline

The data pipeline transitions raw downloads into the single source of truth through three main steps:

```
[Raw GPX/CSV Tracks] ---(1. Combine)---> [gt_raw.csv]
                                             |
                                    (2. Apply Metadata & Filters)
                                             |
                                             v
                            +----------------+----------------+
                            |                                 |
                            v                                 v
                     [gt_clean.csv]                   [gt_removed.csv]
                 (Single Source of Truth)              (Noise & Transport)
```

### 1. Trajectory Combining (`combine_tracks`)
Consolidates raw logs from `data/TRACKS 2026/` into `data/gt_raw.csv`. 
*   Separates distinct deployments on reused trackers based on gaps larger than **5 days** (creating segmented IDs like `Filename_S0`, `Filename_S1`).
*   De-duplicates overlapping or redundant files, prioritizing full CSVs over GPXs.
*   Parses GPS times and converts them to a unified, timezone-naive **America/Los_Angeles (Pacific Time)** representation.

### 2. Algorithmic Noise Removal (`run_cleaning_pipeline`)
Applies advanced spatial and speed filters to isolate biological gull foraging:
*   **Geographic Excise:** Surgically removes all tracking points entering the industrial South Bay corridor and home base south of **37.05° N (Santa Cruz Area)**, representing vehicle transport back to facilities.
*   **Iterative Speed Split Filter:** Identifies high-speed transport noise. Any point with a calculated ground speed exceeding **75 km/hr** relative to its predecessor is removed, and adjacent split speeds are iteratively recalculated.

### 3. Metadata Time Bounds Filtering
Crucially aligns and crops tracking logs to their biological windows:
*   Reads deployment and recovery date/time fields from the Excel sheet.
*   Converts timezone-naive local Pacific Time bounds into UTC.
*   Seamlessly aligns track Pacific timestamps with UTC metadata timestamps to crop out all pre-deployment testing (e.g. at the colony, on the desk) and post-recovery transport.
*   Aligning this timezone boundary correctly prevents the truncation of 7-8 hours of valid foraging data at the beginning/end of deployments.

---

## 4. Running the Pipeline

To re-combine and re-clean the datasets after modifying manual removals or adding new raw tracking logs:

```bash
# Process all years automatically (2019, 2025, and 2026)
uv run python3 src/main.py data process

# Process a specific year only
uv run python3 src/main.py data process --year 2019
uv run python3 src/main.py data process --year 2025
uv run python3 src/main.py data process --year 2026
```

To view or manually flag coordinates for removal using the interactive dashboard or track editor:

```bash
# Launch interactive Streamlit dashboard (includes year selector)
uv run python3 src/main.py launch dashboard

# Launch manual track cleaner (includes year selector)
uv run python3 src/main.py launch cleaner
```
